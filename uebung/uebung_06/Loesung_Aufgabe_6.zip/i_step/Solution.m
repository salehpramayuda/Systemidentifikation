A=[1 -0.9];
B=0.5;
C=[1 0.5];
D=[1 -1];
d=1;
[E1,F1,G1,H1]=i_step_bj_model(A,B,C,D,d,1)
[E2,F2,G2,H2]=i_step_bj_model(A,B,C,D,d,2)
